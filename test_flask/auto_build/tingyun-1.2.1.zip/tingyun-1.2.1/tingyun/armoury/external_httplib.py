
"""this module is defined to detect the httplib module. the cross application trace will be start at there. because of
this lib is the basic lib for all of request lib
"""


