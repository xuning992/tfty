Tingyun Python Agent
======================

Thanks for trying the Tingyun Python Agent

(C) Copyright 2007-2015 Networkbench Inc. All rights reserved.

See the 'INSTALL' file for installation instructions.

See the 'tingyun/LICENSE' file for the licenses covering this software.
