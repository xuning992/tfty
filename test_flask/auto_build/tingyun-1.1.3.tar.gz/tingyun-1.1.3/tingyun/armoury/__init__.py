
"""define some weapons and ammunition.

"""