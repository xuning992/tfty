
"""This module define all of the command entrance for corps
   More interface will be opened in the future.
"""
from tingyun.embattle import initialize

preheat_fight = initialize
